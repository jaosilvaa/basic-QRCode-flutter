import 'package:flutter/material.dart';
import 'package:qrqrcode/scr/data/services/local_storageService.dart';
import 'package:qrqrcode/scr/domain/models/scan_result.dart';

class FavoritesController extends ChangeNotifier{
  final LocalStorageService _localStorageService = LocalStorageService();
  List<ScanResult>  _favoriteQrCodes = [];
  bool _isLoading = false;

  List<ScanResult> get favoriteQrCodes => _favoriteQrCodes;
  bool get isLoading => _isLoading;

  FavoritesController(){
    loadFavorites();
  }

  Future<void> loadFavorites() async {
    _isLoading = true;
    notifyListeners();
    _favoriteQrCodes = await _localStorageService.getSavedQrCodes();
    _isLoading = false;
    notifyListeners();
  }

    Future<bool> addFavorite(ScanResult result) async {
      
      final bool wasSaved = await _localStorageService.saveQrCode(result);

      if (wasSaved) {
        await loadFavorites(); 
      }
      return wasSaved;
    }

  Future<void> removeFavorite(String id) async {
    await _localStorageService.removeQrCode(id);
    await loadFavorites();
  }

  bool isFavorite(ScanResult result){
    return _favoriteQrCodes.any((fav) => fav.id == result.id || (fav.rawValue == result.rawValue && fav.type == result.type));
  }

  ScanResult? findFavoriteByRawValue(String rawValue) {
    try {
    
      return _favoriteQrCodes.firstWhere((fav) => fav.rawValue == rawValue);
    } catch (e) {
      return null;
    }
  }
}