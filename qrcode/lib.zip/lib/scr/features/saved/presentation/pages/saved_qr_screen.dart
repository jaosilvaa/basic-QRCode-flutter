import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:qrqrcode/scr/features/result/model/favorite_model.dart';
import 'package:qrqrcode/scr/features/saved/presentation/widgets/saved_qr_card.dart';

class SavedQrScreen extends StatefulWidget{
  const SavedQrScreen({super.key});

  @override
  State<SavedQrScreen> createState() => _SavedQrScreenState();
}
class _SavedQrScreenState extends State<SavedQrScreen> {

  @override
  void initState(){
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<FavoritesController>(context, listen: false).loadFavorites();
    });
  }

  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      drawer: const Drawer(
        backgroundColor: Colors.white,
        
      ),
      appBar: AppBar(
        backgroundColor: Colors.black,
        centerTitle: true,
        title: const Text(
          'Histórico',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),

      body: Consumer<FavoritesController>(
        builder: (context, favoritesController, child){
          if(favoritesController.favoriteQrCodes.isEmpty){
            return const Center(
              child: Text(
                'Nenhum QR Code favorito salvo ainda.',
                style: TextStyle(color: Colors.white54, fontSize: 16),
                textAlign: TextAlign.center,
              ),
            );
          }
          return ListView.builder(
            itemCount: favoritesController.favoriteQrCodes.length,
            itemBuilder: (context, index) {
              final scanResult = favoritesController.favoriteQrCodes[index];
              return SavedQrCard(scanResult: scanResult);
            },
          );

        }
      ),
    );
  }

}