import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:qrqrcode/scr/domain/models/qr_type.dart';
import 'package:qrqrcode/scr/features/create/generate_qr_code_screen.dart';

class CreateQrCodeScreen extends StatelessWidget{
  const CreateQrCodeScreen({super.key});

  void _navigateToGenerateScreen(BuildContext context, QRType type){
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => GenerateQrCodeScreen(type: type),
      )
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text(
          "Create QR Code",
          style: TextStyle(color: Colors.white),
        ),

        elevation: 0,
        backgroundColor: Colors.transparent,
      ),
      drawer: const Drawer(),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Select an option to create\nyour QR Code.",
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w500,
              ),
            ),

            const SizedBox(height: 24),
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 12.0,
                mainAxisSpacing: 12.0,
                childAspectRatio: 163 / 188,

                children: [
                  _QrCodeOptionCard(
                    icon: LucideIcons.type,
                    text: 'Create new\nText',
                    iconBackgroundColor: const Color(0xFFBBFB4C),
                    iconColor: Colors.black,
                    onTap: (){
                      _navigateToGenerateScreen(context, QRType.plainText);
                    },
                  ),
                  _QrCodeOptionCard(
                    icon: LucideIcons.wifi,
                    text: 'Create new\nWifi',
                    iconBackgroundColor: const Color(0xFFFFFAFF),
                    iconColor: Colors.black,
                    onTap: (){
                      print("navegando wifi.......");
                    },
                  ),
                  _QrCodeOptionCard(
                    icon: LucideIcons.link,
                    text: 'Create new\nURL',
                    iconBackgroundColor: const Color(0xFFFFFAFF),
                    iconColor: Colors.black,
                    onTap: (){
                      _navigateToGenerateScreen(context, QRType.url);
                    },
                  ),
                  _QrCodeOptionCard(
                    icon: LucideIcons.userRound,
                    text: 'Create new\nContact',
                    iconBackgroundColor: const Color(0xFFFFFAFF),
                    iconColor: Colors.black,
                    onTap: (){
                      print("navegando contact.......");
                    },
                  ),
                ],

              ),
            )
          ],
        ),
      ),
    );
  }

}

class _QrCodeOptionCard extends StatelessWidget{
  final IconData icon;
  final String text;
  final Color iconBackgroundColor;
  final Color iconColor;
  final VoidCallback onTap;

  const _QrCodeOptionCard({
    required this.icon,
    required this.text,
    required this.iconBackgroundColor,
    required this.iconColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xFF18191B),
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 58.75 / 2,
                backgroundColor: iconBackgroundColor,
                child: Icon(
                  icon, 
                  size: 24.55,
                  color: iconColor,
                ),
              ),
              const SizedBox(height: 23),

              Text(
                text,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}