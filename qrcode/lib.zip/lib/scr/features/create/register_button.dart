import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class RegisterButton extends StatelessWidget{
  final VoidCallback onPressed;

  const RegisterButton({
    super.key,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 295,
      height: 48,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF18191B),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
            side: const BorderSide(color: Color(0xFF2D2D2D), width: 1.5),
          ),
          elevation: 0
        ),
      child: const Text(
        'Register',
        style: TextStyle(

          color: Colors.white,
          fontSize: 16,
          fontWeight: FontWeight.w600,
        ),
      ),
      ),
    );
  }
}