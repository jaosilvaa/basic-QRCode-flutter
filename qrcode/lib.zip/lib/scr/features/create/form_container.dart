import 'package:flutter/material.dart';

class FormContainer extends StatelessWidget{
  final Widget child;

  const FormContainer({
    super.key,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.bottomCenter,
      clipBehavior: Clip.none,
      children: [
        Container(
          height: 50,
          decoration: BoxDecoration(
            color: const Color(0XFFBBFB4C),
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(27),
              topRight: Radius.circular(27),
            ),
          ),
        ),

        Positioned(
          bottom: 15,
          left: 0,
          right: 0,
          child: Container(
            padding: const EdgeInsets.fromLTRB(25, 30, 25, 20),
            decoration: const BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(27),
                topRight: Radius.circular(27),
              )
            ),
            child: child,
          ),
        ),
        Positioned(
          bottom: 15,
          child: Container(
            width: 48.35,
            height: 3.69,
            decoration: BoxDecoration(
              color: const Color(0xFF18191B),
              borderRadius: BorderRadius.circular(20),
            ),
          ),
        )

      ],
    );
  }
}