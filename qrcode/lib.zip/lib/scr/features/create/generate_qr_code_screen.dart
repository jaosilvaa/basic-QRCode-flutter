import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:qrqrcode/scr/features/create/custom_form_field.dart';
import 'package:qrqrcode/scr/features/create/form_container.dart';
import 'package:qrqrcode/scr/features/create/register_button.dart';
import 'package:qrqrcode/scr/domain/models/qr_type.dart';

class GenerateQrCodeScreen extends StatefulWidget {
  final QRType type;

  const GenerateQrCodeScreen({super.key, required this.type});

  @override
  State<GenerateQrCodeScreen> createState() => _GenerateQrCodeScreenState();
}

// 1. ADICIONADO 'SingleTickerProviderStateMixin'
// Isso ajuda o Flutter a gerenciar animações e transições de tela de forma mais suave,
// o que é crucial para evitar o congelamento que você está experienciando.
class _GenerateQrCodeScreenState extends State<GenerateQrCodeScreen> with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  String? _qrData;

  // Controladores para os campos
  final _textController = TextEditingController();
  final _ssidController = TextEditingController();
  final _passwordController = TextEditingController();
  final _urlController = TextEditingController();

  String _selectedNetworkType = 'WPA/WPA2';
  bool _isPasswordVisible = false;

  @override
  void dispose() {
    _textController.dispose();
    _ssidController.dispose();
    _passwordController.dispose();
    _urlController.dispose();
    super.dispose();
  }

  String _getAppBarTitle() {
    switch (widget.type) {
      case QRType.plainText:
        return 'Text';
      case QRType.wifi:
        return 'Wifi';
      case QRType.url:
        return 'URL';
      default:
        return 'Create';
    }
  }

  void _generateQrCode() {
    if (_formKey.currentState!.validate()) {
      String data = '';
      switch (widget.type) {
        case QRType.plainText:
          data = _textController.text;
          break;
        case QRType.wifi:
          data = 'WIFI:T:$_selectedNetworkType;S:${_ssidController.text};P:${_passwordController.text};;';
          break;
        case QRType.url:
          data = _urlController.text;
          break;
        default:
          break;
      }
      setState(() {
        _qrData = data;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(title: Text('Reto')),
      // 2. ADICIONADO 'SingleChildScrollView'
      // Isso torna a tela rolável, prevenindo erros de layout (overflow) quando
      // o teclado aparece, o que também melhora a performance geral.
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: MediaQuery.of(context).size.height * 0.4, // Altura flexível
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Center(
                  child: _qrData == null
                      ? Image.asset('assets/images/qr_placeholder.png', width: 180, height: 180)
                      : QrImageView(
                          data: _qrData!,
                          version: QrVersions.auto,
                          size: 180.0,
                        ),
                ),
              ),
            ),
            if (_qrData != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 20.0),
                child: ElevatedButton.icon(
                  onPressed: () {
                    // Lógica para compartilhar
                  },
                  icon: const Icon(LucideIcons.send, size: 20),
                  label: const Text('SHARE'),
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.black,
                    backgroundColor: Colors.white,
                    elevation: 4,
                    shadowColor: Colors.black.withOpacity(0.2),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                  ),
                ),
              ),
            FormContainer(
              child: Form(
                key: _formKey,
                child: _buildFormFields(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFormFields() {
    switch (widget.type) {
      case QRType.plainText:
        return _buildTextForm();
      case QRType.wifi:
        return _buildWifiForm();
      case QRType.url:
        return _buildUrlForm();
      default:
        return const Text('Formulário não implementado', style: TextStyle(color: Colors.white));
    }
  }

  Widget _buildTextForm() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        CustomFormField(
          label: 'Text',
          hintText: 'ScanLinker text',
          controller: _textController,
        ),
        const SizedBox(height: 20),
        RegisterButton(onPressed: _generateQrCode),
      ],
    );
  }

  Widget _buildUrlForm() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        CustomFormField(
          label: 'URL',
          hintText: 'https://example.com',
          controller: _urlController,
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'URL não pode ficar vazia.';
            }
            if (!Uri.parse(value).isAbsolute) {
              return 'Por favor, insira uma URL válida.';
            }
            return null;
          },
        ),
        const SizedBox(height: 20),
        RegisterButton(onPressed: _generateQrCode),
      ],
    );
  }

  Widget _buildWifiForm() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomFormField(
          label: 'SSID',
          hintText: 'Nome da sua rede Wi-Fi',
          controller: _ssidController,
        ),
        const SizedBox(height: 16),
        const Text('Tipo de Rede', style: TextStyle(color: Colors.grey, fontSize: 12)),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          decoration: BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: const Color(0xFF2D2D2D), width: 1.5),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: _selectedNetworkType,
              isExpanded: true,
              icon: const Icon(LucideIcons.chevronDown, color: Color(0xFF797A7D)),
              dropdownColor: const Color(0xFF18191B),
              style: const TextStyle(color: Color(0xFF797A7D)),
              onChanged: (String? newValue) {
                setState(() {
                  _selectedNetworkType = newValue!;
                });
              },
              items: <String>['WEP', 'WPA/WPA2']
                  .map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
          ),
        ),
        const SizedBox(height: 16),
        CustomFormField(
          label: 'Set Password',
          hintText: '********',
          controller: _passwordController,
          obscureText: !_isPasswordVisible,
          suffixIcon: IconButton(
            icon: Icon(
              _isPasswordVisible ? LucideIcons.eye : LucideIcons.eyeOff,
              color: const Color(0xFF797A7D),
            ),
            onPressed: () {
              setState(() {
                _isPasswordVisible = !_isPasswordVisible;
              });
            },
          ),
        ),
        const SizedBox(height: 20),
        Center(child: RegisterButton(onPressed: _generateQrCode)),
      ],
    );
  }
}