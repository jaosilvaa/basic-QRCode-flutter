enum QRType{
  url,
  email,
 // phone,
 // sms,
  wifi,
 // vcard,
  plainText,
  unknown,
}